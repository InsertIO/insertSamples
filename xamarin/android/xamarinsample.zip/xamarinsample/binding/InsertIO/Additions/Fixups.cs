﻿//namespace Mozilla.Javascript
//{
//	public partial class NativeObject
//	{
//		global::System.Collections.ICollection global::Java.Util.IMap.EntrySet ()
//		{
//			return this.EntrySet () as global::Android.Runtime.JavaSet;
//		}
//
//		global::System.Collections.ICollection global::Java.Util.IMap.KeySet ()
//		{
//			return this.KeySet () as global::Android.Runtime.JavaSet;
//		}
//
//		global::System.Collections.ICollection global::Java.Util.IMap.Values ()
//		{
//			return this.Values () as global::Android.Runtime.JavaSet;
//		}
//	}
//
//	public partial class Node
//	{
//		public partial class NodeIterator
//		{
//			global::Java.Lang.Object global::Java.Util.IIterator.Next ()
//			{
//				return this.Next ();
//			}
//		}
//	}
//}

