﻿using System;
using Android.App;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Insert.IO;
using Insert.IO.Actions;
using Insert.IO.Views.Custom;

[assembly: UsesPermission(Android.Manifest.Permission.Internet)]

namespace InsertIOTest
{
	[Activity(Label = "InsertIOTest", MainLauncher = true, Icon = "@mipmap/icon")]
	public class MainActivity : Activity
	{
		protected override void OnCreate(Bundle savedInstanceState)
		{
			base.OnCreate(savedInstanceState);

			SetContentView(Resource.Layout.Main);

			var button = FindViewById<Button>(Resource.Id.button);
			var layout = FindViewById<LinearLayout>(Resource.Id.layout);

			button.Click += delegate
			{
			};

			//var circular = new InsertCircularCloseButton(this);
			//var cmd = new InsertCommand(
			//	null,
			//	"source",
			//	"destination",
			//	InsertCommandAction.InsertCommandActionAny,
			//	InsertCommandEventType.InsertCommandEventTypeAny,
			//	InsertCommand.InsertCommandScope.InsertCommandScopeAny);
			//circular.SetActions(new[] { cmd });
			//layout.AddView(circular, new ViewGroup.LayoutParams(128, 128));
		}
	}

	[Application]
	public class SampleApp : Application
	{
		protected SampleApp(IntPtr javaReference, JniHandleOwnership transfer)
			: base(javaReference, transfer)
		{
		}

		public override void OnCreate()
		{
			base.OnCreate();

			Console.WriteLine("Calling InitSDK...");

			Insert.IO.Insert.InitSDK(
				this,
				"a6b004bc3ba6bb8f219df41582adafe1447ab6575c79b13d3e4a845f50ec8baa26c8f3571ad0333d4a2236faee16ddb73ec908cceaf226e7e2cacd09e559e879d87221ed67c17fd7556546e21750f10e.339bfd1430e1a6cad22871a946f572ed.bc7669c297513d545997b5b8ec3053b66428b8dbadcb0b7faf9b2a9374969fb7",
				"xamarin",
				new Callbacks());

			Console.WriteLine("InitSDK returned.");
		}
	}

	public class Callbacks : Java.Lang.Object, IInsertPhasesCallbackInterface
	{
		public void OnInitComplete()
		{
			Console.WriteLine("Init complete.");
		}

		public void OnInitFailed()
		{
			Console.WriteLine("Init failed.");
		}

		public void OnInitStarted()
		{
			Console.WriteLine("Init started...");
		}
	}
}
